# Algoscale Assignment Task

In this assignemnt we have created a interface for Admin to add students and companies and later view the list of all students and companies.The panel gives Admin two options- Students and Interview where they can choose and accordingly add and keep track of records.

# Software Requirements

1. Node.js 8 or above
2. MongoDB 4.2



# setup
    npm install
    nodemon index.js



# How Application Works

1. Employee sign-in or sign-up.
2. In header you will get to choose between students list, interviews list.
3. If Admin go into students list, they can add new students.
4. If Admin go into interview list, they can add new companies.
5. Admin can view list of all students and companies

